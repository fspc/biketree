<?php
$cfg_company="The Bike Root";
$cfg_address="Murray Fraser Hall,
University of Calgary,
Calgary, AB";
$cfg_phone="403-481-4221";
$cfg_email="info@bikeroot.ca";
$cfg_fax="";
$cfg_website="http://www.bikeroot.ca";
$cfg_other="";
$cfg_server="localhost";
$cfg_database="variousa_biketree";
$cfg_username="variousa_biketre";
$cfg_password="9T*v_BD]@(XA";
$cfg_tableprefix="";
$cfg_default_tax_rate="0";
$cfg_currency_symbol="$";
$cfg_theme="serious";
$cfg_numberForBarcode="Row ID";
$cfg_language="english.php";
$cfg_reqmembership="1";
$cfg_membershipID="1";
$cfg_sellToNonMembers="1";
$cfg_emailFromAddress="receipts@goodlifebikes.ca";
$cfg_dailyLateFee="2";
$cfg_mailmanLocation="yourdomain.ca";
$cfg_mailmanListName1="newsletter";
$cfg_mailmanListName2="volunteers";
$cfg_mailmanListName3="steering";
$cfg_mailmanPass="yourpassword";
$cfg_adminAutoSignin="1";
$cfg_mechAutoSignin="option";
$cfg_administratorTitle="Administrator";
$cfg_mechanicTitle="Mechanic";
$cfg_mustOpen="0";


?>
