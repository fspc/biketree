<?php
/*English Language File*/

class language
{
	/*Login Start*/
	var $login='Login';
    var $loginWelcomeMessage='Welcome to the \'Bike Tree\' bike co-op Management System. To&nbsp; continue, please login using your username and&nbsp;password below.';
    var $username='Username';
    var $password='Password';
    var $go='Go!';
	/*Login End*/
	
		
	/*Menubar Start*/
    var $home='Home';
    var $customers='Members';
    var $items='Items';
    var $reports='Reports';
    var $sales='Sales';
    var $salesNow='NEW';
    var $config='Config';
    var $poweredBy='Based loosely on';
    var $welcome='Welcome';
    var $logout='Logout';
	/*Menubar End*/

	
	/*Home Start*/
	var $welcomeTo='Welcome to';
	var $adminHomeWelcomeMessage='Point of Sale system.&nbsp;You are currently logged in<br>as an administrator.<br> With administrative rights, you can go anywhere and do anything on this system.&nbsp;<br>Alternatively, you may select from the following common administrative tasks:';

    var $salesClerkHomeWelcomeMessage='Point of Sale system! To begin,<br>please select the Sales option from the navigation menu.';
    var $reportViewerHomeWelcomeMessage='Point of Sale system! To begin,<br>please select the Reports option from the navigation menu.';
    var $backupDatabase='Backup Database';
    var $processSale='Process A Sale';
    var $addRemoveManageUsers='Add, Remove or Manage Users';
    var $addRemoveManageCustomers='Add, Remove Or Manage Members';
    var $addRemoveManageItems='Add, Remove or Manage Items for Sale';
    var $viewReports='View Reports';
    var $configureSettings='Configure Bike Tree Settings';
    var $viewOnlineSupport='View Online Support';
	/*Home End*/
	
	
	/*Users Home Start*/
	var $createUser='Create a New User';
    var $manageUsers='Manage Users';	
    /*Users Home End*/
	
	
	/*Users Form Start*/
	var $addUser='Add User';
	var $usedInLogin='used in login';
    var $type='Type';
    var $admin='Admin';
    var $salesClerk='Shop Attendant';
    var $reportViewer='Report Viewer';
    var $confirmPassword='Confirm Password';
	/*Users Form End*/


	/*Manage Users Start*/
	var $searchForUser='Search for User (By username)';
    var $searchedForUser='Searched for username';
	var $deleteUser='Delete User';
    var $updateUser='Update User';
	/*Manage Users End*/
	
	
	/*Customers Home Start*/
    var $customersWelcomeScreen='Welcome to the Members panel!&nbsp;Here you can manage our members database. What would you like to do?';
    var $createNewCustomer='Create A New Member';
    var $manageCustomers='Manage Members';
    var $customersBarcode='Members Barcode Sheet';
	/*Customers Home End*/
    
    
 	/*Customers Form Start*/
 	var $addCustomer='Add Customer';
    var $firstName='First Name';
    var $lastName='Last Name';
    var $accountNumber='Account Number';
    var $phoneNumber='Phone Number';
    var $email='E-Mail';
    var $streetAddress='Street Address';
    var $commentsOrOther='Comments/Other';
 	/*Customers Form End*/
 	
 	
 	/*Manage Customers Start*/
 	var $updateCustomer='Update Member';
    var $deleteCustomer='Delete Member';
    var $searchForCustomer='Search for Member';
    var $searchedForCustomer='Searched for Member';
	var $listOfCustomers='List of Members';
	var $getinfo='Get Info/Records';

	/*Manage Customers End*/
	
	
	/*Items Home Start*/
    var $itemsWelcomeScreen='Welcome to the Items panel.&nbsp; Here you manage Items, Brands, Categories and Suppliers.&nbsp; Before you can process a sale, you need to add at least one category, one brand, one supplier, and one item.&nbsp;<br>What would 


you like to do?';
    var $createNewItem='Create a New Item';
    var $manageItems='Manage Items';
    var $manageItems2='Manage Items NEW!';
    var $discountAnItem='Discount an item';
    var $manageDiscounts='Manage Discounts';
    var $itemsBarcode='Items Barcode Sheet';
    var $createBrand='Create a New Brand';
    var $manageBrands='Manage Brands';
    var $createCategory='Create a New Category';
    var $manageCategories='Manage Categories';
    var $createSupplier='Create a New Supplier';
    var $manageSuppliers='Manage Suppliers';
	/*Items Home End*/	
 	
 	
 	/*Items Form Start*/
 	var $itemName='Item Name';
    var $description='Description';
    var $itemNumber='Item Number';
    var $brand='Brand';
    var $category='Category';
    var $supplier='Supplier';
    var $buyingPrice='Buying Price';
    var $sellingPrice='Selling Price';
    var $tax='Tax';
    var $supplierCatalogue='Supplier Catalogue #';
    var $quantityStock='Quantity in Stock';
    var $reorderLevel='Reorder Level';
 	var $users='Users';
    var $itemsInBoldRequired='Items in bold are required';
    var $update='Update';
    var $delete='Delete';
    var $addItem='Add Item';
    var $brandsCategoriesSupplierError='You must create brands, categories, and suppliers before creating an item<br><a href=index.php>Back to Items Main</a>';
    var $finalSellingPricePerUnit='Final Selling Price per Unit';
	/*Items Form End*/
	
	
	/*Manage Items Start*/
	var $updateItem='Update Item';
    var $deleteItem='Delete Item';
    var $searchForItem='Search for Item (By Item Name)';
    var $searchForItemBy='Search for Item';
    var $searchBy='by';
    var $searchedForItem='Searched for item';
    var $listOfItems='List Of Items';
    var $showOutOfStock='Show Out of Stock Items';
    var $outOfStock='Out of Stock Items';
    var $showReorder='Show Items that need to be reordered';
    var $reorder='Items that need to be reordered';
	/*Manage Items End*/
	
    /*Discount From Start*/
    var $addDiscount='Add Discount';
    var $percentOff='Percent Off';
    var $comment='Comment';
    /*Discount From End*/
    
    
    /*Manage Discounts Start*/
    var $searchForDiscount='Search for discount (By percent off)';
    var $searchedForDiscount='Searched for discount';
    var $listOfDiscounts='List Of Discounts';
    var $updateDiscount='Update Discount';
    var $deleteDiscount='Delete Discount';
    /*Manage Discounts End*/
    
    /*Brands Form Start*/
    var $brandName='Brand Name';
    var $addBrand='Add Brand';
	/*Brands Form End*/
    
    
    /*Manage Brands Start*/
    var $searchForBrand='Search for brand (By brand name)';
    var $searchedForBrand='Searched for brand';
    var $listOfBrands='List Of Brands';
    var $updateBrand='Update Brand';
    var $deleteBrand='Delete Brand';
	/*Manage Brands End*/
    
    
    /*Categories Form Start*/
    var $categoryName='Category Name';
    var $addCategory='Add Category';
	/*Categories Form End*/


    /*Manage Categories Start*/
	var $searchForCategory='Search for category (By category name)';
    var $searchedForCategory='Searched for category';
    var $listOfCategories='List of categories';
    var $updateCategory='Update Category';
    var $deleteCategory='Delete Category';
    /*Manage Categories End*/
    
    
    /*Suppliers Form Start*/
    var $supplierName='Supplier Name';
    var $address='Address';
    var $contact='Contact';
    var $other='Other';
	/*Suppliers Form End*/


    /*Manage Suppliers Start*/
    var $listOfSuppliers='List Of Suppliers';
    var $searchForSupplier='Search for supplier (By supplier name)';
    var $searchedForSupplier='Searched for supplier';
    var $addSupplier='Add Supplier';
    var $updateSupplier='Update Supplier';
    var $deleteSupplier='Delete Supplier';
    /*Manage Suppliers End*/


	/*Reports Home Start*/
	var $reportsWelcomeMessage='Welcome to the Reports panel!&nbsp; Here you can view reports based on sales.&nbsp;<br>What would you like to do?';
    var $allCustomersReport='All_Members_Report';
    var $allEmployeesReport='All_Employees_Report';
    var $allBrandsReport='All_Brands_Report';
    var $allCategoriesReport='All_Categories_Report';
    var $allItemsReport='All_Items_Report';
    var $allItemsReportDateRange='All_Items_Report_(DateRange)';
    var $brandReport='Brand_Report';
    var $categoryReport='Category_Report';
    var $customerReport='Members_Report';
    var $customerReportDateRange='Member_Report_(DateRange)';
    var $dailyReport='Daily_Report';
    var $dateRangeReport='Date_Range_Report';
    var $employeeReport='Employee_Report';
    var $itemReport='Item_Report';
    var $itemReportDateRange='Item_Report_(DateRange)';
    var $profitReport='Profit_Report';
    var $taxReport='Tax_Report';
    var $notFound='was not found';
	/*Reports Home End*/
	
	
	/*Input Needed Form Start*/
	var $inputNeeded='Input needed for';
    var $dateRange='Date Range';
    var $today='Today';
    var $yesterday='Yesterday';
    var $last7days='Last 7 Days';
    var $lastMonth='Last Month';
    var $thisMonth='This Month';
    var $thisYear='This Year';
    var $allTime='All Time';
    var $findBrand='Find Brand';
    var $selectBrand='Select Brand';
    var $findCategory='Find Category';
    var $selectCategory='Select Category';
    var $findCustomer='Find Member';
    var $selectCustomer='Select Member';
    var $findEmployee='Find Employee';
    var $selectEmployee='Select Employee';
    var $findItem='Find Item';
    var $selectItem='Select Item';
    var $selectTax='Select Tax';
	/*Input Needed Form End*/
    
    
    /*"All" Reports Start*/
		
		/*All Customers Report Start*/
		var $itemsPurchased='Items Purchased';
   		var $moneySpentBeforeTax='Money Spent before tax';
    	var $moneySpentAfterTax='Money Spent after tax';
		var $totalItemsPurchased='Total Items Purchased';
		/*All Customers Report End*/
		
		/*All Brands Report Start*/
		var $totalsForBrands='Totals For Brands';
		/*All Brands Report End*/

		/*All Categories Report Start*/
		var $totalsForCategories='Totals For Categories';
		/*All Categories Report End*/

		/*All Employees Report Start*/
		var $totalItemsSold='Total Items Sold';
    	var $moneySoldBeforeTax='Money Sold before tax';
		var $moneySoldAfterTax='Money Sold after tax';
		/*All Employees Report End*/
		
		/*All Items Report Start*/
		var $numberPurchased='Number Purchased';
   		var $subTotalForItem='Sub Total For Item';
        var $totalForItem='Total For Item';
		/*All Items Report End*/
	
	/*"All" Reports End*/
	
	
	/*Other Reports Start*/
	var $paidWith='Paid With';
    var $soldBy='Sold By';
    var $saleDetails='Sale details';
    var $saleSubTotal='Sale Sub Total';
    var $saleTotalCost='Sale Total Cost';
    var $showSaleDetails='Show Sale Details';
    var $listOfSaleBy='List of Sales by';
    var $listOfSalesFor='List Of Sales for';
    var $listOfSalesBetween='List Of Sales<br>between dates';
    var $and='and';
    var $between='between';
    var $totalWithOutTax='Total (w/o Tax)';
    var $totalWithTax='Total (w/ Tax)';
	var $fromMonth='From Month';
    var $day='Day';
    var $year='Year';
    var $toMonth='To Month';
    var $totalAmountSoldWithOutTax='Total Amount Sold (w/o tax)';
    var $profit='Profit';
    var $totalAmountSold='Total Amount Sold';
    var $totalProfit='Total Profit';
    var $totalsShownBetween='Totals shown for sales between';
    var $totalItemCost='Total Item Cost';
	/*Other Reports End*/
		
		
	/*Sales Home Start*/
	var $salesWelcomeMessage='Welcome to the Sales panel!&nbsp; Here you can enter sales and manage them.&nbsp;What would you like to do?';
    var $startSale='Start A New Sale';
    var $manageSales='Manage Sales';
	/*Sales Home End*/
	
	
	/*Sale Interface Start*/
    var $yourShoppingCartIsEmpty='Your Shopping Cart is Empty';
    var $addToCart='Add To Cart';
    var $clearSearch='Clear Search';
    var $saleComment='Sale Comment';
    var $addSale='Add Sale';
    var $quantity='Quantity';
    var $remove='Remove';
    var $cash='Cash';
	var $check='Check';
	var $credit='Credit';
	var $giftCertificate='Gift Certificate';
	var $account='Account';
	var $mustSelectCustomer='You must select a member';
	var $newSale='New Sale';
	var $clearSale='Clear Sale';
	var $newSaleBarcode='New Sale using barcode scanner';
	var $scanInCustomer='Scan in member';
	var $scanInItem='Scan in item';
	var $shoppingCart='Shopping Cart';
	var $customerID='Member ID';
	var $itemID='Item ID';
	var $amtTendered='Amt Tendered'; 
    var $amtChange='CHANGE'; 
    var $outOfStockWarn='OUT OF STOCK';
    var $globalSaleDiscount='Global Sale Discount (%)';
	/*Sale Interface End*/
	
	
	/*Sale Receipt Start*/
	var $orderBy='Order by';
	var $itemOrdered='Item Name';
	var $extendedPrice='Extended Price';
	var $saleID='Sale ID';
	var $orderFor='Order For';
	/*Sale Receipt End*/


	/*Manage Sales Start*/
	var $searchForSale='Search for Sale (By Sale ID Range)';
	var $searchedForSales='Searched for sales between';
	var $highID='high id';
	var $lowID='low id';
	var $incorrectSearchFormat='Incorect Search Format, please try again';
	var $updateRowID='Update row id';
	var $updateSaleID='Update Sale id';
	var $itemsInSale='Items In Sale';
	var $itemTotalCost='Item Total Cost';
	var $updateSale='Update Sale';
	var $deleteEntireSale='Delete Entire Sale';
	var $customerName='Member Name';
	var $unitPrice='Unit Price';
	/*Manage Sales End*/
	
	
	/*Config Start*/
	var $configurationWelcomeMessage='Welcome!&nbsp; This is the Configuration panel for Bike Tree.&nbsp; Here you can modify co-op information, themes, and other options.&nbsp;Fields in bold are required.';
    var $companyName='Co-op Name';
    var $fax='Fax';
    var $website='Website';
    var $theme='Theme';
    var $taxRate='Tax Rate';
    var $inPercent='in percent';
    var $currencySymbol='Currency Symbol';
    var $barCodeMode='Bar Code Mode';
    var $language='Language';
    var $yes='Yes';
    var $no='No';
    var $usePaidMembership='Require Paid Membership?';
    var $membershipItemID='Item ID of paid membership';
    var $sellToNonMembers='Sell to members:';
    var $everyone='All Members';
    var $onlyinshop='Only signed in members';
    var $emailFromAddress='"From" address for automatic e-mails:';
    var $dailyLateFee='Daily Late Fee for Loans';
    var $mailmanLocation='Mailman Location';
    var $mailmanListName='Name of mailing list';
    var $mailmanPass='Mailman List Password';
    var $mustOpen='Count cash at open/close?';
    var $adminAutoSignin='Auto sign in admin';
    var $mechAutoSignin='Auto sign in mechanic';//"yes", "no", "option"
    var $administratorTitle="Administrator title";
    var $mechanicTitle="Mechanic title";	

	/*Config End*/
	
	
	/*Error Messages Start*/
	var $youDoNotHaveAnyDataInThe='You do not have any data in the';
    var $attemptedSecurityBreech='Attempted Secuirty breech, you are not a possible user type.';
    var $mustBeAdmin='You must be an Admin to view this page.';
    var $mustBeReportOrAdmin='You must be a Report Viewer or Admin to view this page.';
    var $mustBeSalesClerkOrAdmin='You must be a Sales Clerk or Admin to view this page.';
    var $youMustSelectAtLeastOneItem='You must select at least one Item';
    var $refreshAndTryAgain='Refresh and try again';
	var $noActionSpecified='No action specified! No data was inserted, changed or deleted.';
	var $mustUseForm='You must use the form in order to enter data.';
	var $forgottenFields='You have forgotten one or more of the required fields';
	var $passwordsDoNotMatch='Your passwords do not match!';
	var $logoutConfirm='Are you sure you want to logout?';
	var $usernameOrPasswordIncorrect='username or password are incorrect';
	var $mustEnterNumeric='You must enter a numeric value for price, tax percent, and quantity.';
	var $moreThan200='There are more than 200 rows in the';
	var $first200Displayed='table, only the first 200 rows are displayed. Please use the search feature.';
	var $noDataInTable='You do not have any data in the';
	var $table='table';
	var $confirmDelete='Are you sure you want to delete this from the';
	var $invalidCharactor='You have entered an invalid character in one or more of the fields, please hit back and try again';
	var $didNotEnterID='You did not enter an ID';
	var $cantDeleteBrand='You can not delete this brand because at least one of your items uses it.';
	var $cantDeleteCategory='You can not delete this category because at least one of your items uses it.';
	var $cantDeleteCustomer='You can not delete this member because he/she has purchased at least one item.';
	var $cantDeleteItem='You can not delete this item because it has been purchased at least once.';
	var $cantDeleteSupplier='You can not delete this supplier because at least one of your items uses it.';
	var $cantDeleteUserLoggedIn='You can not delete this user because you are logged in as them!';
	var $cantDeleteUserEnteredSales='You can not delete this user because he/she has entered sales.';
	var $itemWithID='Item with id';
	var $isNotValid='is not valid.';
	var $customerWithID='Member with id';
	var $configUpdatedUnsucessfully='The configuration file was not updated, please make sure the settings.php file is writeable';
	var $problemConnectingToDB='There was a problem connecting to the database,<br> please hit back and verify your settings.';
	/*Error Messages End*/
    
    
    /*Success Messages Start*/
	var $upgradeMessage='Clicking submit will upgrade the database to version 9.0.  You must have version 7.0 or greater to upgrade PHP Point Of Sale.';
	var $upgradeSuccessfullMessage='PHP Point Of Sale\'s database has been successfully upgraded to version 9.0, please delete the upgrade and install folders for security purposes.';
	var $successfullyAdded='You have succesfully added this in table';
	var $successfullyUpdated='You have succesfully updated this in table';
	var $successfullyDeletedRow='You have succesfully deleted row';
	var $fromThe='from the';
	var $configUpdatedSuccessfully='The configuration file was updated successfully';
	var $installSuccessfull='The installation of PHP Point Of Sale was successfull,<br> please click <a href=../login.php>here</a> to login and get started!';
	/*Success Messages End*/


	/*Installer Start*/
	var $installation='Installation';
	var $installerWelcomeMessage='Welcome to the install process for PHP Point of Sale. We\'re very excited that you\'ve<br>&nbsp;&nbsp;&nbsp;&nbsp; decided to use PHP PoS as your point of sale solution.&nbsp;To continue the installation process,<br>&nbsp;


&nbsp;&nbsp;&nbsp; please fill out the simple form below and then click  the \'Install\' button.&nbsp;';
	var $databaseServer='Database Server';
	var $databaseName='Database Name';
	var $databaseUsername='Database Username';
	var $databasePassword='Database Password';
	var $mustExist='Must Exist';
	var $defaultTaxRate='Default Tax Rate';
	var $tablePrefix='Table Prefix';
	var $numberToUseForBarcode='Property to use when scanning barcodes at sale';
	var $whenYouFirstLogIn='Important, when you first login your username is';
	var $yourPasswordIs='your password is';
	var $install='Install';
	var $serious='Serious';
	var $bigBlue='Big Blue';
	var $percent='Percent';
	/*Installer End*/
	
	
	/*Generic Start*/
    var $name='Name';
    var $customer='Member';
    var $employee='Employee';
    var $date='Date';
    var $rowID='Row ID';
    var $field='Field';
	var $data='Data';
	var $quantityPurchased='Quantity Purchased';
	var $listOf='List Of';
	var $wo='w/o';//without
	/*Generic End*/
    
}	

?>
