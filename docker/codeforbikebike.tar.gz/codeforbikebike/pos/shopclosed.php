<?php session_start();
echo "You're done. Get out of here!";
?>